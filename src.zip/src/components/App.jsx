import React from 'react';
import Search from './Search';
import Listview from './Listview';
import { useGlobalContext } from '../context';

 const App = () => {
   
  return (
    <>
    
    <div className="main">

    
    <Listview/>
    </div>
    </>
  )
}
export default App;